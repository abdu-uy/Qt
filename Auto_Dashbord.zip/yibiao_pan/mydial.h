#ifndef MYDIAL_H
#define MYDIAL_H

#include <QWidget>
#include<QPainter>
#include<QLabel>
class MyDial : public QWidget
{
    Q_OBJECT
public:
    explicit MyDial(QWidget *parent = nullptr);
    void valueChanged(int value);
    void drawBg(QPainter *painter );
    void drawDial(QPainter *paiter);
    void drawScaleNum(QPainter *painter);
    void drawIndicator(QPainter *painter);
    void drawText(QPainter *painter);
    void paintEvent(QPaintEvent *);
signals:

public slots:
private:
    int radius=100;
   double Angle=60;
    int percent=0;
    QPainter p;
};

#endif // MYDIAL_H
