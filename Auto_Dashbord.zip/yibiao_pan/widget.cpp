#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    ui->horizontalSlider->setMaximum(100);
   connect(ui->horizontalSlider, &QSlider::valueChanged, ui->widget, &MyDial::valueChanged);
}

Widget::~Widget()
{
    delete ui;
}
