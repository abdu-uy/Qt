#include "widget.h"
#include"clientwid.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Widget w;
    w.show();

    clientwid w2;
    w2.show();

    return a.exec();
}
