#ifndef WIDGET_H
#define WIDGET_H


#include <QWidget>
#include<QTcpServer>//监听
#include<QTcpSocket>//通信建立

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT


public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();


private slots:
    void on_pushButtonSend_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::Widget *ui;
    QTcpServer *tcpserver;
    QTcpSocket *tcpsocket;
};

#endif // WIDGET_H
