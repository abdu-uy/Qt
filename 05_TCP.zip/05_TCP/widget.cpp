#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{

    ui->setupUi(this);
    this->setWindowTitle("服务器");


    tcpserver=NULL;
    tcpsocket=NULL;

    tcpserver=new QTcpServer(this);
    tcpserver->listen(QHostAddress::Any,8888);
    connect(tcpserver,&QTcpServer::newConnection,
            [=]()
    {
                    tcpsocket=tcpserver->nextPendingConnection();

                    QString ip=tcpsocket->peerAddress().toString();
                    qint16 port=tcpsocket->peerPort();
                    QString temp=QString("[%1:%2]:成功链接").arg(ip).arg(port);
                    ui->textEditRead->setText(temp);

                   connect(tcpsocket,&QTcpSocket::readyRead,
                                [=]()
                                {
                                QByteArray arry=tcpsocket->readAll();
                                ui->textEditRead->append(arry);

                                }
                            );
    }
    );


}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_pushButtonSend_clicked()
{
    if(tcpsocket==NULL){
        return ;
    }
    QString str=ui->textEditSend->toPlainText();
    tcpsocket->write(str.toUtf8().data());
    ui->textEditSend->clear();
}

void Widget::on_pushButton_2_clicked()
{
    if(tcpsocket==NULL){
        return ;
    }
    tcpsocket->disconnectFromHost();
    tcpsocket->close();
    tcpsocket=NULL;
}
