#ifndef CLIENTWID_H
#define CLIENTWID_H

#include <QWidget>
#include<QTcpSocket>

namespace Ui {
class clientwid;
}

class clientwid : public QWidget
{
    Q_OBJECT

public:
    explicit clientwid(QWidget *parent = 0);
    ~clientwid();

private slots:
    void on_btnconn_clicked();

    void on_pushButton_clicked();

    void on_btnclose_clicked();

private:
    Ui::clientwid *ui;
    QTcpSocket *tcpsocket;
};

#endif // CLIENTWID_H
