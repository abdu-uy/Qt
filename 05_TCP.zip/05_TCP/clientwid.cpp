#include "clientwid.h"
#include "ui_clientwid.h"
#include<QMessageBox>
#include<QHostAddress>

clientwid::clientwid(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::clientwid)
{
    ui->setupUi(this);
    this->setWindowTitle("客户端");
    tcpsocket=NULL;
    tcpsocket=new QTcpSocket(this);

    connect(tcpsocket,QTcpSocket::connected,[=]()
                {
                    ui->textEdit->setText("服务器连接成功！");
                }
    );
    connect(tcpsocket,QTcpSocket::readyRead,
            [=]()
                {
                    QByteArray arry=tcpsocket->readAll();
                    ui->textEdit->append(arry);

    }
    );
}

clientwid::~clientwid()
{
    delete ui;
}

void clientwid::on_btnconn_clicked()
{

    QString ip=ui->textip->text();
    qint16 port=ui->textport->text().toInt();
    tcpsocket->connectToHost(QHostAddress(ip),port);

}

void clientwid::on_pushButton_clicked()
{
    QString str=ui->textEdit_2->toPlainText();
    tcpsocket->write(str.toUtf8().data());
    ui->textEdit_2->clear();
}

void clientwid::on_btnclose_clicked()
{
    tcpsocket->disconnectFromHost();
    tcpsocket->close();
}
