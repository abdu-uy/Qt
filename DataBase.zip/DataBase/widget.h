#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include<QSqlTableModel>
#include<QSqlQueryModel>
#include<QTableView>
#include<QLineEdit>
#include<QPushButton>
#include<QSqlDatabase>
#include<QSqlQuery>
#include<QSqlRecord>
#include<QDebug>

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();
    QSqlTableModel* _model;
    QTableView* _view;
    QLineEdit* _filter;
    QPushButton* _add;
    QPushButton* _delet;
    QPushButton* _reset;
    QPushButton* _submit;
    void cover();
private slots:
    void on_pushButton_clicked();



    void on_pushButton_query_clicked();


    void on_comboBox_table_currentTextChanged(const QString &arg1);

    void on_comboBox_selec_table_currentTextChanged(const QString &arg1);

    void on_pushButton_add_clicked();

    void on_pushButton_delete_selected_clicked();

    void on_pushButton_2_clicked();

    void on_groupBox_2_clicked();

    void on_pushButton_modification_confirm_clicked();

private:
    Ui::Widget *ui;
    bool Ok;
    QSqlDatabase db;

};

#endif // WIDGET_H
