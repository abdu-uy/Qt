﻿#include "widget.h"
#include "ui_widget.h"

#include<QMessageBox>
#include<QTextCodec>


Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    ui->tableView->resizeColumnsToContents();
    cover();
     ui->label_query_res->hide();
     ui->groupBox_data_2->hide();
     ui->pushButton_modification_confirm->hide();



}

Widget::~Widget()
{
    delete ui;
}
//数据库连接
void Widget::on_pushButton_clicked()
{
        db=QSqlDatabase::addDatabase("QMYSQL");
        db.setHostName("127.0.0.1");
        db.setPort(3306);
        db.setDatabaseName("lab2");
        db.setUserName("root");
        db.setPassword("root");

   Ok=db.open();
    if(Ok){
        QMessageBox::information(this,"infor","link success!");
        db.exec("SET NAMES 'Latin1'");
    }
    else{
        QMessageBox::warning(this,"error","link failed!");
    }
    _model=new QSqlTableModel();
}

//数据库表查询
void Widget::on_pushButton_query_clicked()
{
//    QSqlQuery query;
//   query.exec(QString("select * from %1 where %2=%3")
//              .arg(ui->comboBox_table->currentText(),
//                   ui->comboBox_colum->currentText(),
//                   ui->lineEdit_condition->text()));


   QSqlQueryModel *qsqm=new QSqlQueryModel(ui->tableView);
   qsqm->setQuery(QString("select * from %1 where %2=%3")
                  .arg(ui->comboBox_table->currentText(),
                       ui->comboBox_colum->currentText(),
                       ui->lineEdit_condition->text()));

   if(ui->comboBox_table->currentText()=="client"){
       qsqm->setHeaderData(0,Qt::Horizontal,tr("IdCard"));
       qsqm->setHeaderData(1,Qt::Horizontal,tr("CellPhone"));
       qsqm->setHeaderData(2,Qt::Horizontal,tr("Email"));
       qsqm->setHeaderData(3,Qt::Horizontal,tr("Adress"));
       qsqm->setHeaderData(4,Qt::Horizontal,tr("Relatives"));
       qsqm->setHeaderData(5,Qt::Horizontal,tr("ResponsibleStuff"));
   }
   else if(ui->comboBox_table->currentText()=="account"){
       qsqm->setHeaderData(0,Qt::Horizontal,tr("AccountType"));
       qsqm->setHeaderData(1,Qt::Horizontal,tr("AccountId"));
       qsqm->setHeaderData(2,Qt::Horizontal,tr("IdCard"));
       qsqm->setHeaderData(3,Qt::Horizontal,tr("Balence"));
       qsqm->setHeaderData(4,Qt::Horizontal,tr("AccountCreateDate"));
       qsqm->setHeaderData(5,Qt::Horizontal,tr("AccountCreateBank"));
       qsqm->setHeaderData(6,Qt::Horizontal,tr("RecentAccessDate"));

   }
   else if(ui->comboBox_table->currentText()=="bank"){
       qsqm->setHeaderData(0,Qt::Horizontal,tr("City"));
       qsqm->setHeaderData(1,Qt::Horizontal,tr("BankName"));
       qsqm->setHeaderData(2,Qt::Horizontal,tr("Asset"));
       qsqm->setHeaderData(3,Qt::Horizontal,tr("UserNum"));
   }
   else if(ui->comboBox_table->currentText()=="loan"){
       qsqm->setHeaderData(0,Qt::Horizontal,tr("LoanId"));
       qsqm->setHeaderData(1,Qt::Horizontal,tr("IdCard"));
       qsqm->setHeaderData(2,Qt::Horizontal,tr("BorrowSum"));
       qsqm->setHeaderData(3,Qt::Horizontal,tr("PayState"));
       qsqm->setHeaderData(4,Qt::Horizontal,tr("RealPay"));
       qsqm->setHeaderData(5,Qt::Horizontal,tr("PayDate"));
   }
   else if(ui->comboBox_table->currentText()=="save"){
       qsqm->setHeaderData(0,Qt::Horizontal,tr("SaveId"));
       qsqm->setHeaderData(1,Qt::Horizontal,tr("IdCard"));
       qsqm->setHeaderData(2,Qt::Horizontal,tr("BankName"));
       qsqm->setHeaderData(3,Qt::Horizontal,tr("MoneySum"));
       qsqm->setHeaderData(4,Qt::Horizontal,tr("Date"));
   }
   ui->tableView->setModel(qsqm);
   //ui->tableView->verticalHeader()->hide();

}


void Widget::on_comboBox_table_currentTextChanged(const QString &arg1)
{
    ui->comboBox_colum->clear();
    ui->label_query_res->hide();
    if(arg1=="client"){
        QStringList lst;

        lst.append("IdCard");
        lst.append("CellPhone");
        lst.append("Email");
        lst.append("Adress");
        lst.append("Relatives");
        lst.append("ResponsibleStuff");
        ui->comboBox_colum->addItems(lst);
    }
    else if(arg1=="account"){
        QStringList lst;

        lst.append("AccountType");
        lst.append("AccountId");
        lst.append("IdCard");
        lst.append("Balence");
        lst.append("AccountCreateDate");
        lst.append("AccountCreateBank");
        lst.append("RecentAccessDate");

        ui->comboBox_colum->addItems(lst);
    }
    else if(arg1=="bank"){
        QStringList lst;

        lst.append("City");
        lst.append("BankName");
        lst.append("Asset");
        lst.append("UserNum");

        ui->comboBox_colum->addItems(lst);
    }
    else if(arg1=="loan"){
        QStringList lst;

        lst.append("LoanId");
        lst.append("IdCard");
        lst.append("BorrowSum");
        lst.append("PayState");
        lst.append("RealPay");
        lst.append("PayDate");

        ui->comboBox_colum->addItems(lst);
    }
    else if(arg1=="save"){
        QStringList lst;

        lst.append("SaveId");
        lst.append("IdCard");
        lst.append("BankName");
        lst.append("MoneySum");
        lst.append("Date");
        ui->comboBox_colum->addItems(lst);
    }
}

//数据库表插入



void Widget::on_comboBox_selec_table_currentTextChanged(const QString &arg1)
{
    QString str=arg1;
    if(ui->comboBox_selec_table->currentText()=="client"){
        ui->label_add_data->setText("IdCard :");
        ui->label_add_data->show();
        ui->lineEdit_add->show();
        ui->label_add_data_2->setText("CellPhone :");
        ui->label_add_data_2->show();
        ui->lineEdit_add_2->show();
        ui->label_add_data_3->setText("Email :");
        ui->label_add_data_3->show();
        ui->lineEdit_add_3->show();
        ui->label_add_data_4->setText("Adress :");
        ui->label_add_data_4->show();
        ui->lineEdit_add_4->show();
        ui->label_add_data_5->setText("Relatives :");
        ui->label_add_data_5->show();
        ui->lineEdit_add_5->show();
        ui->label_add_data_66->setText("ResponsibleStuff :");
        ui->label_add_data_66->show();
        ui->lineEdit_add_66->show();
    }
    else if(ui->comboBox_selec_table->currentText()=="account"){
        cover();
        ui->label_add_data->setText("AccountType :");
        ui->label_add_data->show();
        ui->lineEdit_add->show();
        ui->label_add_data_2->setText("AccountId :");
        ui->label_add_data_2->show();
        ui->lineEdit_add_2->show();
        ui->label_add_data_3->setText("IdCard :");
        ui->label_add_data_3->show();
        ui->lineEdit_add_3->show();
        ui->label_add_data_4->setText("Balence :");
        ui->label_add_data_4->show();
        ui->lineEdit_add_4->show();
        ui->label_add_data_5->setText("AccountCreateDate :");
        ui->label_add_data_5->show();
        ui->lineEdit_add_5->show();
        ui->label_add_data_66->setText("AccountCreateBank :");
        ui->label_add_data_66->show();
        ui->lineEdit_add_66->show();



    }
    else if(ui->comboBox_selec_table->currentText()=="bank"){
        cover();
        ui->label_add_data->setText("City :");
        ui->label_add_data->show();
        ui->lineEdit_add->show();
        ui->label_add_data_2->setText("BankName :");
        ui->label_add_data_2->show();
        ui->lineEdit_add_2->show();
        ui->label_add_data_3->setText("Asset :");
        ui->label_add_data_3->show();
        ui->lineEdit_add_3->show();
        ui->label_add_data_4->setText("UserNum :");
        ui->label_add_data_4->show();
        ui->lineEdit_add_4->show();
    }
    else if(ui->comboBox_selec_table->currentText()=="loan"){
        cover();
        ui->label_add_data->setText("LoanId :");
        ui->label_add_data->show();
        ui->lineEdit_add->show();
        ui->label_add_data_2->setText("IdCard :");
        ui->label_add_data_2->show();
        ui->lineEdit_add_2->show();
        ui->label_add_data_3->setText("BorrowSum :");
        ui->label_add_data_3->show();
        ui->lineEdit_add_3->show();
        ui->label_add_data_4->setText("PayState :");
        ui->label_add_data_4->show();
        ui->lineEdit_add_4->show();
        ui->label_add_data_5->setText("RealPay :");
        ui->label_add_data_5->show();
        ui->lineEdit_add_5->show();
        ui->label_add_data_66->setText("PayDate :");
        ui->label_add_data_66->show();
        ui->lineEdit_add_66->show();
    }
    else if(ui->comboBox_selec_table->currentText()=="save"){
        cover();
        ui->label_add_data->setText("SaveId :");
        ui->label_add_data->show();
        ui->lineEdit_add->show();
        ui->label_add_data_2->setText("IdCard :");
        ui->label_add_data_2->show();
        ui->lineEdit_add_2->show();
        ui->label_add_data_3->setText("BankName :");
        ui->label_add_data_3->show();
        ui->lineEdit_add_3->show();
        ui->label_add_data_4->setText("MoneySum :");
        ui->label_add_data_4->show();
        ui->lineEdit_add_4->show();
        ui->label_add_data_5->setText("Date :");
        ui->label_add_data_5->show();
        ui->lineEdit_add_5->show();
    }
}
void Widget::cover(){
    //隐藏数据标签
    ui->label_add_data->hide();
    ui->label_add_data_2->hide();
    ui->label_add_data_3->hide();
    ui->label_add_data_4->hide();
    ui->label_add_data_5->hide();
    ui->label_add_data_66->hide();

   //隐藏行编辑
    ui->lineEdit_add->hide();
    ui->lineEdit_add_2->hide();
    ui->lineEdit_add_3->hide();
    ui->lineEdit_add_4->hide();
    ui->lineEdit_add_5->hide();
    ui->lineEdit_add_66->hide();

    ui->label_add_result->hide();
}

void Widget::on_pushButton_add_clicked()
{

    QSqlQuery query(db);
    if(ui->comboBox_selec_table->currentText()=="client"){

            QString insertSql="insert into client(IdCard,CellPhone,Email,Adress,Relatives,ResponsibleStuff) values('%1','%2','%3','%4','%5','%6')";
            insertSql=insertSql.arg(ui->lineEdit_add->text(),ui->lineEdit_add_2->text(),
                                    ui->lineEdit_add_3->text(),ui->lineEdit_add_4->text(),
                                    ui->lineEdit_add_5->text(),ui->lineEdit_add_66->text());
            qDebug()<<insertSql;
            bool res=query.exec(insertSql);
            if(res){
                ui->label_add_result->setText("添加成功！");
                ui->label_add_result->show();
            }
            else{
                ui->label_add_result->setText("添加失败！");
                ui->label_add_result->show();
            }

    }
    else if(ui->comboBox_selec_table->currentText()=="account"){
        if(ui->lineEdit_add_2->text()==""||
                ui->lineEdit_add_3->text()=="")
        {
            QMessageBox::warning(this,"error","AccountId/IdCard必须为数字且不可为空！");
        }
        else{

            QString insertSql="insert into account(AccountType,AccountId,IdCard,Balence,AccountCreateBank,AccountCreateDate) values('%1','%2','%3','%4','%5','%6')";


            insertSql=insertSql.arg(ui->lineEdit_add->text(),ui->lineEdit_add_2->text(),
                                    ui->lineEdit_add_3->text(),ui->lineEdit_add_4->text(),ui->lineEdit_add_5->text(),ui->lineEdit_add_66->text());
            qDebug()<<insertSql;
            bool res=query.exec(insertSql);
            if(res){



                ui->label_add_result->setText("添加成功！");
                ui->label_add_result->show();
            }
            else{
                ui->label_add_result->setText("添加失败！");
                ui->label_add_result->show();
            }
        }
    }
    else if(ui->comboBox_selec_table->currentText()=="bank"){
        if(ui->lineEdit_add->text()==""||
                ui->lineEdit_add_2->text()=="")
        {
            QMessageBox::warning(this,"error","BankName不可为空！");
        }
        else{

            QString insertSql="insert into bank(City,BankName,Asset,UserNum) values('%1','%2',%3,'%4')";
            insertSql=insertSql.arg(ui->lineEdit_add->text(),ui->lineEdit_add_2->text(),
                                    ui->lineEdit_add_3->text(),ui->lineEdit_add_4->text());
            qDebug()<<insertSql;
            bool res=query.exec(insertSql);
            if(res){
                ui->label_add_result->setText("添加成功！");
                ui->label_add_result->show();
            }
            else{
                ui->label_add_result->setText("添加失败！");
                ui->label_add_result->show();
            }
        }
    }
    else if(ui->comboBox_selec_table->currentText()=="loan"){
        if(ui->lineEdit_add->text()==""||
                ui->lineEdit_add_2->text()=="")
        {
            QMessageBox::warning(this,"error","LoanId不可为空！");
        }
        else{

            QString insertSql="insert into loan(LoanId,IdCard,BorrowSum,PayState,RealPay,PayDate) values(%1,'%2',%3,'%4','%5','%6')";
            insertSql=insertSql.arg(ui->lineEdit_add->text(),ui->lineEdit_add_2->text(),
                                    ui->lineEdit_add_3->text(),ui->lineEdit_add_4->text(),ui->lineEdit_add_5->text(),ui->lineEdit_add_66->text());
            qDebug()<<insertSql;
            bool res=query.exec(insertSql);
            if(res){
                ui->label_add_result->setText("添加成功！");
                ui->label_add_result->show();
            }
            else{
                ui->label_add_result->setText("添加失败！");
                ui->label_add_result->show();
            }
        }
    }
    else if(ui->comboBox_selec_table->currentText()=="save"){
        if(ui->lineEdit_add->text()==""||
                ui->lineEdit_add_2->text()=="")
        {
            QMessageBox::warning(this,"error","SaveId/IdCard不可为空");
        }
        else{

            QString insertSql="insert into save(SaveId,IdCard,BankName,MoneySum,Date) values('%1','%2',%3,'%4','%5')";
            insertSql=insertSql.arg(ui->lineEdit_add->text(),ui->lineEdit_add_2->text(),
                                    ui->lineEdit_add_3->text(),ui->lineEdit_add_4->text(),ui->lineEdit_add_5->text());
            qDebug()<<insertSql;
            bool res=query.exec(insertSql);
            if(res){
                ui->label_add_result->setText("添加成功！");
                ui->label_add_result->show();
            }
            else{
                ui->label_add_result->setText("添加失败！");
                ui->label_add_result->show();
            }
        }
    }

}

//数据库表删除
void Widget::on_pushButton_delete_selected_clicked()
{

    //得到并删除数据库数据
    int curRow=ui->tableView->currentIndex().row();

    QModelIndex index=ui->tableView->currentIndex();


     //删除数据库中的数据
    QSqlQuery query(db);
    QString deleteSql,check_sql;
    deleteSql="delete from %1 where %2=%3";
    check_sql="select %1 from %2 where %3='%4'";



    if(ui->comboBox_table->currentText()=="client"){
        QString id=index.sibling(curRow,0).data().toString();
        check_sql=check_sql.arg((QString)"IdCard",(QString)"loan",(QString)"IdCard",id);
        query.exec(check_sql);
        query.next();
        qDebug()<<check_sql;
        qDebug()<<query.value(0).toString();

            if(query.value(0).toString()==id){
                QMessageBox::information(this,"infor","有未还的贷款无法删除!");
            }
            else{
                deleteSql=deleteSql.arg(ui->comboBox_table->currentText(),(QString)"IdCard",id);
            }






    }
    else if(ui->comboBox_table->currentText()=="account"){
         QString id=index.sibling(curRow,1).data().toString();
        deleteSql=deleteSql.arg(ui->comboBox_table->currentText(),(QString)"AccountId",id);

    }
    else if(ui->comboBox_table->currentText()=="bank"){
        QString id=index.sibling(curRow,0).data().toString();
        deleteSql=deleteSql.arg(ui->comboBox_table->currentText(),(QString)"City",id);
    }
    else if(ui->comboBox_table->currentText()=="loan"){
        QString id=index.sibling(curRow,0).data().toString();
        deleteSql=deleteSql.arg(ui->comboBox_table->currentText(),(QString)"LoanId",id);
    }
    else if(ui->comboBox_table->currentText()=="save"){
        QString id=index.sibling(curRow,0).data().toString();
        deleteSql=deleteSql.arg(ui->comboBox_table->currentText(),(QString)"SaveId",id);
    }
    qDebug()<<deleteSql;
    bool is_okay=query.exec(deleteSql);
    if(is_okay){
       ui->label_query_res->setText("删除成功！");
    }
    else{
        ui->label_query_res->setText("删除失败");
    }
    ui->label_query_res->show();

}

//数据库表修改

void Widget::on_pushButton_2_clicked()
{
    int curRow=ui->tableView->currentIndex().row();

    QModelIndex index=ui->tableView->currentIndex();
    //QString id=index.sibling(curRow,0).data().toString();

    if(ui->comboBox_table->currentText()=="client"){
        ui->lineEdit_add_6->setText(index.sibling(curRow,0).data().toString());
        ui->lineEdit_add_7->setText(index.sibling(curRow,1).data().toString());
        ui->lineEdit_add_8->setText(index.sibling(curRow,2).data().toString());
        ui->lineEdit_add_9->setText(index.sibling(curRow,3).data().toString());
        ui->lineEdit_add_10->setText(index.sibling(curRow,4).data().toString());
        ui->lineEdit_add_11->setText(index.sibling(curRow,5).data().toString());
        ui->label_add_data_6->setText("IdCard");
        ui->label_add_data_7->setText("CellPhone");
        ui->label_add_data_8->setText("Email");
        ui->label_add_data_9->setText("Adress");
        ui->label_add_data_10->setText("Relatives");
        ui->label_add_data_11->setText("ResponsibleStuff");

        ui->lineEdit_add_10->show();
        ui->label_add_data_10->show();
        ui->lineEdit_add_11->show();
        ui->label_add_data_11->show();

    }
    else if(ui->comboBox_table->currentText()=="account"){
        ui->lineEdit_add_6->setText(index.sibling(curRow,0).data().toString());
        ui->lineEdit_add_7->setText(index.sibling(curRow,1).data().toString());
        ui->lineEdit_add_8->setText(index.sibling(curRow,2).data().toString());
        ui->lineEdit_add_9->setText(index.sibling(curRow,3).data().toString());
        ui->lineEdit_add_10->setText(index.sibling(curRow,4).data().toString());
        ui->lineEdit_add_11->setText(index.sibling(curRow,5).data().toString());

        ui->label_add_data_6->setText("AccountType");
        ui->label_add_data_7->setText("AccountId");
        ui->label_add_data_8->setText("IdCard");
        ui->label_add_data_9->setText("Balence");
        ui->label_add_data_10->setText("AccountCreateDate");
        ui->label_add_data_11->setText("AccountCreateBank");

        ui->lineEdit_add_10->show();
        ui->label_add_data_10->show();
        ui->lineEdit_add_11->show();
        ui->label_add_data_11->show();

    }
    else if(ui->comboBox_table->currentText()=="bank")
    {
        ui->lineEdit_add_6->setText(index.sibling(curRow,0).data().toString());
        ui->lineEdit_add_7->setText(index.sibling(curRow,1).data().toString());
        ui->lineEdit_add_8->setText(index.sibling(curRow,2).data().toString());
        ui->lineEdit_add_9->setText(index.sibling(curRow,3).data().toString());

        ui->label_add_data_6->setText("City");
        ui->label_add_data_7->setText("BankName");
        ui->label_add_data_8->setText("Asset");
        ui->label_add_data_9->setText("UserNum");

        ui->lineEdit_add_10->hide();
        ui->label_add_data_10->hide();
        ui->lineEdit_add_11->hide();
        ui->label_add_data_11->hide();
    }
    else if(ui->comboBox_table->currentText()=="loan")
    {
        ui->lineEdit_add_6->setText(index.sibling(curRow,0).data().toString());
        ui->lineEdit_add_7->setText(index.sibling(curRow,1).data().toString());
        ui->lineEdit_add_8->setText(index.sibling(curRow,2).data().toString());
        ui->lineEdit_add_9->setText(index.sibling(curRow,3).data().toString());
        ui->lineEdit_add_10->setText(index.sibling(curRow,4).data().toString());
        ui->lineEdit_add_11->setText(index.sibling(curRow,5).data().toString());



        ui->label_add_data_6->setText("LoanID");
        ui->label_add_data_7->setText("IdCard");
        ui->label_add_data_8->setText("BorrowSum");
        ui->label_add_data_9->setText("PayState");
        ui->label_add_data_10->setText("RealPay");
        ui->label_add_data_11->setText("PayDate");



    }

    else if(ui->comboBox_table->currentText()=="save")
    {
        ui->lineEdit_add_6->setText(index.sibling(curRow,0).data().toString());
        ui->lineEdit_add_7->setText(index.sibling(curRow,1).data().toString());
        ui->lineEdit_add_8->setText(index.sibling(curRow,2).data().toString());
        ui->lineEdit_add_9->setText(index.sibling(curRow,3).data().toString());
        ui->lineEdit_add_10->setText(index.sibling(curRow,4).data().toString());




        ui->label_add_data_6->setText("SaveId");
        ui->label_add_data_7->setText("IdCard");
        ui->label_add_data_8->setText("BankName");
        ui->label_add_data_9->setText("MoneySum");
        ui->label_add_data_10->setText("Date");

        ui->lineEdit_add_11->hide();
        ui->label_add_data_11->hide();

    }




    ui->tableView->hide();
    ui->groupBox_data_2->show();
    ui->pushButton_2->hide();
    ui->pushButton_modification_confirm->show();


}

void Widget::on_groupBox_2_clicked()
{
    ui->tableView->hide();
    ui->groupBox_data_2->show();
}

void Widget::on_pushButton_modification_confirm_clicked()
{



     //修改数据库中的数据
    QSqlQuery query(db);
    QString modifySql;


    if(ui->comboBox_table->currentText()=="client"){
        modifySql="update client set IdCard='%1',CellPhone='%2',Email='%3',Adress='%4',Relatives='%5',ResponsibleStuff='%6' where IdCard=%1";
        modifySql=modifySql.arg(ui->lineEdit_add_6->text(),ui->lineEdit_add_7->text(),ui->lineEdit_add_8->text(),
                                ui->lineEdit_add_9->text(),ui->lineEdit_add_10->text(),ui->lineEdit_add_11->text());
        qDebug()<<modifySql;
        bool res=query.exec(modifySql);
        if(res){
            qDebug()<<"修改成功！";
        }
        else{
            qDebug()<<"修改失败！";
        }
    }
    else if(ui->comboBox_table->currentText()=="account"){
        modifySql="update account set AccountType='%1',AccountId='%2',IdCard='%3',Balence='%4',AccountCreateDate='%5',AccountCreateBank='%6' where IdCard=%2";
        modifySql=modifySql.arg(ui->lineEdit_add_6->text(),ui->lineEdit_add_7->text(),ui->lineEdit_add_8->text(),
                                ui->lineEdit_add_9->text(),ui->lineEdit_add_10->text(),ui->lineEdit_add_11->text());
        qDebug()<<modifySql;
        bool res=query.exec(modifySql);
        if(res){
            qDebug()<<"修改成功！";
        }
        else{
            qDebug()<<"修改失败！";
        }
    }
    else if(ui->comboBox_table->currentText()=="bank"){
        modifySql="update bank set City='%1',BankName='%2',Asset='%3',UserNum='%4' where BankName='%2'";
        modifySql=modifySql.arg(ui->lineEdit_add_6->text(),ui->lineEdit_add_7->text(),ui->lineEdit_add_8->text(),
                                ui->lineEdit_add_9->text());
        qDebug()<<modifySql;
        bool res=query.exec(modifySql);
        if(res){
            qDebug()<<"修改成功！";
        }
        else{
            qDebug()<<"修改失败！";
        }
    }

    else if(ui->comboBox_table->currentText()=="loan"){
        modifySql="update loan set LoanId=%1,IdCard='%2',BorrowSum='%3',PayState='%4',RealPay='%5',PayDate='%6' where LoanId=%1";
        modifySql=modifySql.arg(ui->lineEdit_add_6->text(),ui->lineEdit_add_7->text(),ui->lineEdit_add_8->text(),
                                ui->lineEdit_add_9->text(),ui->lineEdit_add_10->text(),ui->lineEdit_add_11->text());
        qDebug()<<modifySql;
        bool res=query.exec(modifySql);
        if(res){
            qDebug()<<"修改成功！";
        }
        else{
            qDebug()<<"修改失败！";
        }
    }

    else if(ui->comboBox_table->currentText()=="save"){
        modifySql="update save set SaveId=%1,IdCard='%2',BankName='%3',MoneySum='%4',Date='%5' where SaveId=%1";
        modifySql=modifySql.arg(ui->lineEdit_add_6->text(),ui->lineEdit_add_7->text(),ui->lineEdit_add_8->text(),
                                ui->lineEdit_add_9->text(),ui->lineEdit_add_10->text());
        qDebug()<<modifySql;
        bool res=query.exec(modifySql);
        if(res){
            qDebug()<<"修改成功！";
        }
        else{
            qDebug()<<"修改失败！";
        }
    }





    ui->tableView->show();
    ui->groupBox_data_2->hide();
    ui->pushButton_2->show();
    ui->pushButton_modification_confirm->hide();
}






