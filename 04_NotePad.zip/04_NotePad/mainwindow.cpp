#include "mainwindow.h"
#include "ui_mainwindow.h"

#include<QMessageBox>
#include<QFile>
#include<QFileDialog>
#include<QTextStream>
#include<QDebug>
#include<QPrintDialog>
#include<QPrinter>
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("كونسىپىت");
    this->setWindowIcon(QIcon(":/2260/07fef0625cd310c0d5609b0311a8ef53.jpeg"));
    this->setCentralWidget(ui->textEdit);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_actionNew_triggered()
{
        file_path="";
        ui->textEdit->setText("");
}
//open file
void MainWindow::on_actionOpen_triggered()
{
    QString file_name=QFileDialog::getOpenFileName(this,tr("ھۆججەتنى ئچىش"),
                                                   "/",
                                                   tr("TXT (*.txt)"));
    qDebug()<<file_name;
    if(file_name!=NULL)
    file_path=file_name;

    QFile file(file_name);
    if(!file.open(QFile::ReadOnly|QFile::Text)){
        //QMessageBox::warning(this,"文档","文件未打开！");
        return;
    }
    QTextStream in(&file);
    QString text=in.readAll();
    ui->textEdit->setText(text);
    file.close();
}
//save file
void MainWindow::on_actionSave_triggered()
{
    //QString file_name=QFileDialog::getSaveFileName(this,"Open file");
    if(file_path==NULL){
        MainWindow::on_actionSave_as_triggered();
    }
    else{
        qDebug()<<file_path;
        QFile file(file_path);
        if(!file.open(QFile::WriteOnly|QFile::Text)){
            //QMessageBox::warning(this,"文档","文件未打开！");
            return;
        }
        QTextStream out(&file);
        QString text=ui->textEdit->toPlainText();
        out << text;
        file.flush();
        file.close();
    }
}
//save as file
void MainWindow::on_actionSave_as_triggered()
{
    QString file_name=QFileDialog::getSaveFileName(this,"باشقا ساقلاش");
    qDebug()<<file_name;
    QFile file(file_name);
    if(file_name!=NULL)
    file_path=file_name;

    if(!file.open(QFile::WriteOnly|QFile::Text)){
        //QMessageBox::warning(this,"文档","文件未打开！");
        return;
    }
    QTextStream out(&file);
    QString text=ui->textEdit->toPlainText();
    out << text;
    file.flush();
    file.close();

}

void MainWindow::on_actionCut_triggered()
{
    ui->textEdit->cut();
}

void MainWindow::on_actionCopy_triggered()
{
    ui->textEdit->copy();
}

void MainWindow::on_actionPaste_triggered()
{
    ui->textEdit->paste();
}

void MainWindow::on_actionRedo_triggered()
{
    ui->textEdit->redo();
}

void MainWindow::on_actionUndo_triggered()
{
    ui->textEdit->undo();
}

void MainWindow::on_actionAbout_Notepad_triggered()
{
    QMessageBox::about(this,"ئالاقىدار","نەشىر ھوققۇقى ئابدۇسەمىگە مەنسۇپ!");
}

void MainWindow::on_action_triggered()
{
        QPrinter printer;
        printer.setPrinterName("desired printer name");
        QPrintDialog dialog(&printer,this);
        if(dialog.exec()==QDialog::Rejected)return ;
        ui->textEdit->print(&printer);

}
